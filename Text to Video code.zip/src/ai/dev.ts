import { config } from 'dotenv';
config();

import '@/ai/flows/generate-video-flow';
